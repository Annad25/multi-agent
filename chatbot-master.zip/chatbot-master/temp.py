import os

from dotenv import load_dotenv

load_dotenv(".env")


from typing import Annotated, Sequence
from typing_extensions import TypedDict
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, START
import functools
import operator

from langgraph.checkpoint.memory import MemorySaver


memory = MemorySaver()









# ## Helper Utilities

# Define a helper function that we will use to create the nodes in the graph - it takes care of converting the agent response to a human message. This is important because that is how we will add it the global state of the graph

# In[6]:




# In[7]:


from langchain_core.messages import HumanMessage
from agent_globals import agent_node

from agent_supervisor import supervisor_agent, members
from agent_globals import llm
from multi_agent.math_agent import maths_node
from multi_agent.chemistry_agent import chemistry_node
from multi_agent.physics_agent import physics_node
from multi_tools.agent_tools import empty_tool

from database.chemistry_vectorstore import chemistry_retriever
from database.physics_vectorstore import physics_retriever
from database.math_vectorstore import math_retriever
# ### Create Agent Supervisor

from langchain.tools.retriever import create_retriever_tool
 
physics_search = create_retriever_tool(
   retriever=physics_retriever,
   name="search_physics_query",
   description="Searches and returns excerpts from the Physics documents.",
)
 
 
chemistry_search = create_retriever_tool(
   retriever=chemistry_retriever,
   name="search_chemistry_query",
   description="Searches and returns excerpts from the Chemistry documents.",
)
 
maths_search = create_retriever_tool(
   retriever=math_retriever,
   name="search_maths_query",
   description="Searches and returns excerpts from the Maths documents.",
)

# It will use function calling to choose the next worker node OR finish processing.

# In[8]:


from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from pydantic import BaseModel
from typing import Literal




# In[9]:


supervisor_agent({
        "messages": [
            HumanMessage(content="what is plancks constant. what is the atomic weight of carbon")
        ]
    })


# ## Construct Graph
# 
# We're ready to start building the graph. Below, define the state and worker nodes using the function we just defined.

# In[10]:


import functools
import operator
from typing import Sequence
from typing_extensions import TypedDict

from langchain_core.messages import BaseMessage

from langgraph.graph import END, StateGraph, START
from langgraph.prebuilt import create_react_agent


# The agent state is the input to each node in the graph
class AgentState(TypedDict):
    # The annotation tells the graph that new messages will always
    # be added to the current states
    messages: Annotated[Sequence[BaseMessage], operator.add]
    # The 'next' field indicates where to route to next
    next: str





workflow = StateGraph(AgentState)
workflow.add_node("Maths-Professor", maths_node)
workflow.add_node("Chemistry-Professor", chemistry_node)
workflow.add_node("Physics-Professor", physics_node)
workflow.add_node("supervisor", supervisor_agent)


# In[11]:


llm.invoke("Hi")


# Now connect all the edges in the graph.

# In[12]:


for member in members:
    # We want our workers to ALWAYS "report back" to the supervisor when done
    workflow.add_edge(member, "supervisor")
# The supervisor populates the "next" field in the graph state
# which routes to a node or finishes
conditional_map = {k: k for k in members}
conditional_map["FINISH"] = END
workflow.add_conditional_edges("supervisor", lambda x: x["next"], conditional_map)
# Finally, add entrypoint
workflow.add_edge(START, "supervisor")

#graph = workflow.compile()

graph = workflow.compile(checkpointer=memory)


conditional_map


# In[14]:


# ## Invoke the team
# 
# With the graph created, we can now invoke it and see how it performs!

# In[15]:

def chatbot():
    print("Welcome to the Multi-Professor Chatbot!")
    print("You can ask questions about Math, Physics, and Chemistry.")
    print("Type 'exit' to end the conversation.")

    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == 'exit':
            print("Thank you for using the Multi-Professor Chatbot. Goodbye!")
            break

        # Process the user input through the workflow
        for s in graph.stream(
        {
            "messages": [
                HumanMessage(content= user_input)
            ]
        }, stream_mode="updates"
    ):
            if "__end__" not in s and "supervisor" not in s:
                
                professor_content = s[list(s.keys())[0]]['messages'][0].content
                print(professor_content)
                print("----")

                


chatbot()

from langchain_core.messages import HumanMessage

config = {"configurable": {"thread_id": "2"}}
input_message = HumanMessage(content="hi! I'm bob")
for event in app.stream({"messages": [input_message]}, config, stream_mode="values"):
    event["messages"][-1].pretty_print()


input_message = HumanMessage(content="what's my name?")
for event in app.stream({"messages": [input_message]}, config, stream_mode="values"):
    event["messages"][-1].pretty_print()



