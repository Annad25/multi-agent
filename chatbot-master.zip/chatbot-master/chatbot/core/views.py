from django.shortcuts import render
from django.http import HttpResponse
from .chatbot_helper import chatbot_helper
from django.http import JsonResponse


def chatbot_page(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        response = chatbot_helper(message)
        print(response)
        return JsonResponse({'message': message, 'response': response})
    return render(request,'chatbot.html')


# @csrf_exempt
# def chatbot_view(request):
#     if request.method == 'POST':
#         try:
#             data = json.loads(request.body)
#             user_input = data.get("message", "").strip()

#             if user_input.lower() == 'exit':
#                 response = "Thank you for using the Multi-Professor Chatbot. Goodbye!"
#                 return JsonResponse({"response": response, "end": True})

#             # Process the user input through the workflow
#             config = {"configurable": {"thread_id": 2}}
#             responses = []
            
#             for s in graph.stream(
#                 {
#                     "messages": [
#                         HumanMessage(content=user_input)
#                     ]
#                 }, config, stream_mode="values"
#             ):
#                 if "__end__" not in s and "supervisor" not in s:
#                     response_content = s[list(s.keys())[0]]['messages'][0].content
#                     responses.append(response_content)

#             return JsonResponse({"response": responses, "end": False})
        
#         except json.JSONDecodeError:
#             return JsonResponse({"error": "Invalid JSON"}, status=400)
        
#         except Exception as e:
#             return JsonResponse({"error": str(e)}, status=500)
    
#     return JsonResponse({"error": "Only POST method is allowed"}, status=405)