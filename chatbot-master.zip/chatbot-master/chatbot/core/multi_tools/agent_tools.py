from langchain_community.tools import tool




@tool("empty_tool")
def empty_tool():
    """Empty placeholder tool for agents"""
    return ""

