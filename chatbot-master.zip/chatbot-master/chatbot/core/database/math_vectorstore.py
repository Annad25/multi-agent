from ..database.base_vectorstore import get_retriever_for_subject

math_retriever = get_retriever_for_subject("math")
