from pinecone.grpc import PineconeGRPC as Pinecone
from langchain_pinecone import PineconeVectorStore
from langchain_openai import OpenAIEmbeddings
import time

# configure client
pc = Pinecone()
embeddings = OpenAIEmbeddings()
index_name = "subject-index"

# wait for index to be initialized

index = pc.Index(index_name)
index.describe_index_stats()

# PyMuPDF for parsing PDFs
# Define subject namespaces
namespaces = {
    "math": "math-namespace",
    "physics": "physics-namespace",
    "chemistry": "chemistry-namespace"
}

# Initialize OpenAI embeddings
embeddings = OpenAIEmbeddings()

text_field = "text"


# Function to query the vector store for a specific subject
def get_retriever_for_subject(subject):
    return PineconeVectorStore(index, embeddings, text_field, namespace=namespaces[subject]).as_retriever()
