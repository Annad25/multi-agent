from ..database.base_vectorstore import get_retriever_for_subject

physics_retriever = get_retriever_for_subject("physics")
