import functools
from langgraph.prebuilt import create_react_agent
from ..agent_globals import agent_node
from ..agent_globals import llm
from ..database.math_vectorstore import math_retriever
from langchain.tools.retriever import create_retriever_tool

maths_search = create_retriever_tool(
   retriever=math_retriever,
   name="search_maths_query",
   description="Searches and returns excerpts from the Maths documents.",
)

maths_prompt = """"You are a Maths professor answering queries for high school students. Follow these guidelines:

1. Use the retriever to search relevant documents for maths-related information only.
2. Provide a single paragraph answer, aiming for about 30 words.
3. If you can not find the information for the answer within the relevant document reply with 'I don't know'.
4. Prioritize accuracy over completeness.

Formulate your response based on retrieved information and the above guidelines."""

maths_agent = create_react_agent(llm, tools=[maths_search],state_modifier = maths_prompt)
maths_node = functools.partial(agent_node, agent=maths_agent, name="Maths-Professor")
