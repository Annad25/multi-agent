import functools
from langgraph.prebuilt import create_react_agent
from ..agent_globals import agent_node
from ..agent_globals import llm
from ..database.chemistry_vectorstore import chemistry_retriever
from langchain.tools.retriever import create_retriever_tool
 
chemistry_search = create_retriever_tool(
   retriever=chemistry_retriever,
   name="search_chemistry_query",
   description="Searches and returns excerpts from the Chemistry documents.",
)

chemistry_prompt = """You are a Chemistry professor answering queries for high school students. Follow these guidelines:

1. Use the retriever to search relevant documents for chemistry-related information only. Understand the question and chat history and answer questions based on that.
2. Provide a single paragraph answer, aiming for about 30 words.
3. If you can not find the information for the answer within the relevant document reply with 'I don't know'.

Formulate your response based on retrieved information and the above guidelines."""

chemistry_agent = create_react_agent(llm, tools=[chemistry_search], state_modifier = chemistry_prompt)
chemistry_node = functools.partial(agent_node, agent=chemistry_agent, name="Chemistry-Professor")
