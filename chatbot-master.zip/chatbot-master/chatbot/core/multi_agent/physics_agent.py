import functools
from langgraph.prebuilt import create_react_agent
from ..agent_globals import agent_node
from ..agent_globals import llm
from ..database.physics_vectorstore import physics_retriever
from langchain.tools.retriever import create_retriever_tool

physics_search = create_retriever_tool(
   retriever=physics_retriever,
   name="search_physics_query",
   description="Searches and returns excerpts from the Physics documents.",
) 

physics_prompt = """You are a Physics professor answering queries for high school students. Follow these guidelines:

1. Use the retriever to search the relevant documents for physics-related information only. Understand the question and chat history and answer questions based on that.
2. Provide a single paragraph answer, aiming for about 30 words.
3. If you can not find the information for the answer within the relevant document reply with 'I don't know'.

Formulate your response based on retrieved information and the above guidelines."""

physics_agent = create_react_agent(llm, tools=[physics_search], state_modifier = physics_prompt)
physics_node = functools.partial(agent_node, agent=physics_agent, name="Physics-Professor")
