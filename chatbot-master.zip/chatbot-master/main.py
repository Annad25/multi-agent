import os
from dotenv import load_dotenv
load_dotenv(".env")

from typing import Annotated, Sequence
from typing_extensions import TypedDict
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph, START
import functools
import operator
from langgraph.checkpoint.memory import MemorySaver
from multi_agent.math_agent import maths_node
from multi_agent.chemistry_agent import chemistry_node
from multi_agent.physics_agent import physics_node
from multi_tools.agent_tools import empty_tool
from database.chemistry_vectorstore import chemistry_retriever
from database.physics_vectorstore import physics_retriever
from database.math_vectorstore import math_retriever
from langchain.tools.retriever import create_retriever_tool
from agent_globals import llm
from agent_supervisor import supervisor_agent, members

# Load environment variables
memory = MemorySaver()

# Define Agent State
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], operator.add]
    next: str

# Define helper function to create retriever tools
def create_retriever_tools():
    return {
        "physics": create_retriever_tool(
            retriever=physics_retriever,
            name="search_physics_query",
            description="Searches and returns excerpts from the Physics documents.",
        ),
        "chemistry": create_retriever_tool(
            retriever=chemistry_retriever,
            name="search_chemistry_query",
            description="Searches and returns excerpts from the Chemistry documents.",
        ),
        "math": create_retriever_tool(
            retriever=math_retriever,
            name="search_maths_query",
            description="Searches and returns excerpts from the Maths documents.",
        ),
    }

# Initialize Supervisor Agent
def initialize_supervisor_agent():
    supervisor_agent({
        "messages": [
            HumanMessage(content="what is Planck's constant? What is the atomic weight of carbon?")
        ]
    })

# Construct the workflow graph
def construct_workflow():
    workflow = StateGraph(AgentState)
    workflow.add_node("Maths-Professor", maths_node)
    workflow.add_node("Chemistry-Professor", chemistry_node)
    workflow.add_node("Physics-Professor", physics_node)
    workflow.add_node("supervisor", supervisor_agent)

    # Add edges and conditional logic
    for member in members:
        workflow.add_edge(member, "supervisor")

    conditional_map = {k: k for k in members}
    conditional_map["FINISH"] = END
    workflow.add_conditional_edges("supervisor", lambda x: x["next"], conditional_map)

    # Set starting point
    workflow.add_edge(START, "supervisor")
    
    return workflow.compile(checkpointer=memory)


# Interactive chatbot loop
def chatbot(graph):
    print("Welcome to the Multi-Professor Chatbot!")
    print("You can ask questions about Math, Physics, and Chemistry.")
    print("Type 'exit' to end the conversation.")
    config = {"configurable": {"thread_id": 2}}

    while True:
        user_input = input("\nYou: ")
        if user_input.lower() == 'exit':
            print("Thank you for using the Multi-Professor Chatbot. Goodbye!")
            break

        # Process the user input through the workflow
        for response in graph.stream({"messages": [HumanMessage(content=user_input)]}, config, stream_mode="values"):
            if "__end__" not in response and "supervisor" not in response:
                print(response)
                print("----")

# Main function to run the chatbot
def main():
    create_retriever_tools()
    initialize_supervisor_agent()
    graph = construct_workflow()
    chatbot(graph)

# Run the chatbot
if __name__ == "__main__":
    main()
